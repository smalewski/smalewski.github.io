This script comes in several parts.
images	- if this demo uses images - they are in this folder.
demo.html	- this is a demo of the JavaScript-FX
javascript	- this is a folder containing the code for the demo.
readme.txt	- this file.

To install this script...
1) open demo.html in wordpad or notepad.
2) Copy the code from HEAD section of the demo into the HEAD section of your document.
   (The code is marked BEGIN CUT - END CUT)
3) add the onload="JSFX_StartEffects()" to the BODY tag of your document.
4) upload the folders "images" & "javascript" to your web server.
5) upload your document to your web server.

If you cannot upload folders to your webpage then goto www.JavaScript-FX.com
and under the Help section from the main page read the help on 
"Linking External JS Files".
